#include "xc.h"
#include "rte.h"

void ASW_DcMotorInit()
{
     RTE_DcMotorInit();
}
void ASW_DcMotorDirSpeed()
{
    RTE_SetDcMotorDir(0);
    RTE_setDcMotorDuty();
}

