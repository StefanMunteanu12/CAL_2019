/* 
 * File:   hal_dc.h
 * Author: student
 *
 * Created on November 20, 2019, 8:54 AM
 */

#ifndef HAL_DC_H
#define	HAL_DC_H

#include "general_types.h"

   extern void HAL_DcMotorInit();
    extern void HAL_SetDcMotorDir(BOOL Dir);
    extern void HAL_setDcMotorDuty();
#ifdef	__cplusplus
extern "C" {
    
#endif

   


#ifdef	__cplusplus
}
#endif

#endif	/* HAL_DC_H */

