/* 
 * File:   ASW_Move.h
 * Author: student
 *
 * Created on November 20, 2019, 9:08 AM
 */

#ifndef ASW_MOVE_H
#define	ASW_MOVE_H

#ifdef	__cplusplus
extern "C" {
#endif

   


#ifdef	__cplusplus
}
#endif

#endif	/* ASW_MOVE_H */

extern void ASW_DcMotorInit();
    extern void ASW_DcMotorDirSpeed();
