/* 
 * File:   mcal_adc.h
 * Author: uia94881
 *
 * Created on August 1, 2018, 2:10 PM
 */

#ifndef MCAL_ADC_H
#define	MCAL_ADC_H

#include "general.h"

void ADC_vInit(void);
T_U16 ADC_u16Read(T_U8);

#endif	

