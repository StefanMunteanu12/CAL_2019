/* 
 * File:   rte.h
 * Author: student
 *
 * Created on November 20, 2019, 9:04 AM
 */
#include"hal_dc.h"
#ifndef RTE_H
#define	RTE_H
#define RTE_DcMotorInit  HAL_DcMotorInit
#define RTE_SetDcMotorDir  HAL_SetDcMotorDir
#define RTE_setDcMotorDuty HAL_setDcMotorDuty

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* RTE_H */

