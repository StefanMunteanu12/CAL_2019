/* 
 * File:   mcal_osc.h
 * Author: Cristian T. A.
 *
 * Created on August 1, 2018, 11:16 AM
 */

#ifndef MCAL_OSC_H
#define	MCAL_OSC_H


/* Oscillator init. function */
void OSC_vInit(void);


#endif	/* MCAL_OSC_H */

