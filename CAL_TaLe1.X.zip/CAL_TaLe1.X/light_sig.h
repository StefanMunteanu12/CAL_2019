/* 
 * File:   light_sig.h
 * Author: student
 *
 * Created on November 13, 2019, 8:24 AM
 */

#ifndef LIGHT_SIG_H
#define	LIGHT_SIG_H

#ifdef	__cplusplus

extern "C" {
#endif

    extern void vDoHandleLightSig();
    extern void vDoHandleLightSig2();

#ifdef	__cplusplus
}
#endif

#endif	/* LIGHT_SIG_H */

